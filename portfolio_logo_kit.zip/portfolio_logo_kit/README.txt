DTC Current Portfolio — logo edition
====================================

WHAT THIS DOES
  Rebuilds Current_Portfolio.pptx with each company's logo next to its name.
  Logos it can't fetch are drawn as a Dell-blue monogram chip, so the slide
  always looks finished.

RUN IT (on a machine with normal internet)
  1. npm install pptxgenjs
  2. node build_logos.js
  → writes Current_Portfolio.pptx in this folder.

  First run downloads logos into icons/logos/ (cached, so re-runs are fast).

FIXING A WRONG OR MISSING LOGO
  Open build_logos.js, find the DOMAINS map, correct the company's domain
  (blank "" forces a monogram). Delete that file from icons/logos/ and re-run.
  ~20 of the smaller/stealth companies have no domain guess yet and will show
  as monograms until you add one.

NOTE
  Logo source order is Clearbit (logo.clearbit.com) then Google's favicon
  service. Both are free/no-key. Swap in a paid logo API in the download()
  calls if you want higher-fidelity marks.
