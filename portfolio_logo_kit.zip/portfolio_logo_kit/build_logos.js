/* =======================================================================
   DTC Current Portfolio — logo edition
   -----------------------------------------------------------------------
   ONE command:  node build_logos.js
     1. Fetches each company logo into icons/logos/<slug>.png
        (Clearbit first -> Google favicon fallback). Already-downloaded
        logos are skipped, so re-runs are fast.
     2. Rebuilds Current_Portfolio.pptx with the logo next to each name.
        Any logo it could not fetch is drawn as a Dell-blue monogram chip,
        so the slide always looks finished.

   >>> To fix a wrong/missing logo: correct the domain in the DOMAINS map
       below, delete that file in icons/logos/, and re-run. <<<
   ======================================================================= */

const fs = require("fs");
const path = require("path");
const https = require("https");
const pptxgen = require("pptxgenjs");

// ---- Dell palette ----
const NAVY = "002E5D", BLUE = "0076CE", SKY = "66C7F0", ICE = "CFE3F2";
const CARD = "F3F8FC", BORDER = "DCE8F2", NAME = "203040";
const FONT = "Arial";

// ---- Data (sector -> companies) ----
const sectors = [
  { title: "Cybersecurity & Identity", icon: "icons/cyber.png", cos: [
    "Halcyon","Descope","Oxeye","Secuvy","Twine Security","ThirdLaw","VanishID",
    "Mave Security","Terra Security","Tika Security","Singulr AI","Cequence",
    "Cymulate","Endor Labs","OLOID","Toka" ] },
  { title: "Developer Tools & Observability", icon: "icons/dev.png", cos: [
    "OpenObserve","AppMap","Augment","Ocoder","Sailplane","CUE Labs","OpsMx","Quali" ] },
  { title: "AI Applications & Agents", icon: "icons/aiapps.png", cos: [
    "Distyl AI","Maven AGI","Auditoria","Lilt","Fiber AI","MaxIQ","Series Entertainment",
    "Bland AI","Agentive","AAI","MisaLabs","Picture Capital","Aidaptive","Ibex","Twine","Zingly" ] },
  { title: "AI Infrastructure & Compute", icon: "icons/aiinfra.png", cos: [
    "RunPod","Cartesia","Prime Intellect","Sycamore","Gobi","HF0","Akka","Fly.io",
    "Lightbits Labs","MinIO","Tetrate","VAST Data" ] },
  { title: "Data, Analytics & ML Ops", icon: "icons/data.png", cos: [
    "Skan","Flexor","Savant Labs","SuperAnnotate","Terragrit","Cmatrics","Unilinq",
    "Alation","Bodo","Domino Data Lab","Druva","FullStory","Immuta","Pecan","Redis",
    "SingleStore","Striim","Treeverse","Yugabyte" ] },
  { title: "Silicon, Hardware & Deep Tech", icon: "icons/silicon.png", cos: [
    "Quantum Source","Hyperscale RF","Element Labs","Protocol Nine","SiLC","SiMa" ] },
  { title: "Edge, Logistics & Industrial", icon: "icons/edge.png", cos: [
    "G2RL","LimitlessCNC","BlueBear","Daybreak","Exotec","FloLIVE","IOTech",
    "Tag-N-Trac","Xometry" ] },
];

// ---- Company -> domain (BEST-EFFORT; edit any that are wrong) ----
// Blank string "" = no domain guess -> will render as a monogram chip.
const DOMAINS = {
  // Cybersecurity & Identity
  "Halcyon":"halcyon.ai","Descope":"descope.com","Oxeye":"oxeye.io","Secuvy":"secuvy.ai",
  "Twine Security":"twinesecurity.com","ThirdLaw":"thirdlaw.ai","VanishID":"vanishid.com",
  "Mave Security":"mave.security","Terra Security":"terra.security","Tika Security":"tika.security",
  "Singulr AI":"singulr.ai","Cequence":"cequence.ai","Cymulate":"cymulate.com",
  "Endor Labs":"endorlabs.com","OLOID":"oloid.ai","Toka":"toka.io",
  // Developer Tools & Observability
  "OpenObserve":"openobserve.ai","AppMap":"appmap.io","Augment":"augmentcode.com",
  "Ocoder":"","Sailplane":"","CUE Labs":"cuelabs.dev","OpsMx":"opsmx.com","Quali":"quali.com",
  // AI Applications & Agents
  "Distyl AI":"distyl.ai","Maven AGI":"mavenagi.com","Auditoria":"auditoria.ai","Lilt":"lilt.com",
  "Fiber AI":"fiber.ai","MaxIQ":"maxiq.ai","Series Entertainment":"series.inc","Bland AI":"bland.ai",
  "Agentive":"","AAI":"","MisaLabs":"misalabs.com","Picture Capital":"","Aidaptive":"aidaptive.com",
  "Ibex":"ibex.ai","Twine":"twine.net","Zingly":"zingly.ai",
  // AI Infrastructure & Compute
  "RunPod":"runpod.io","Cartesia":"cartesia.ai","Prime Intellect":"primeintellect.ai",
  "Sycamore":"","Gobi":"","HF0":"hf0.com","Akka":"akka.io","Fly.io":"fly.io",
  "Lightbits Labs":"lightbitslabs.com","MinIO":"min.io","Tetrate":"tetrate.io","VAST Data":"vastdata.com",
  // Data, Analytics & ML Ops
  "Skan":"skan.ai","Flexor":"flexor.ai","Savant Labs":"savantlabs.io","SuperAnnotate":"superannotate.com",
  "Terragrit":"","Cmatrics":"","Unilinq":"","Alation":"alation.com","Bodo":"bodo.ai",
  "Domino Data Lab":"dominodatalab.com","Druva":"druva.com","FullStory":"fullstory.com",
  "Immuta":"immuta.com","Pecan":"pecan.ai","Redis":"redis.io","SingleStore":"singlestore.com",
  "Striim":"striim.com","Treeverse":"lakefs.io","Yugabyte":"yugabyte.com",
  // Silicon, Hardware & Deep Tech
  "Quantum Source":"quantumsource.io","Hyperscale RF":"","Element Labs":"","Protocol Nine":"",
  "SiLC":"silc.com","SiMa":"sima.ai",
  // Edge, Logistics & Industrial
  "G2RL":"","LimitlessCNC":"","BlueBear":"bluebear.io","Daybreak":"daybreak.io","Exotec":"exotec.com",
  "FloLIVE":"flolive.net","IOTech":"iotechsys.com","Tag-N-Trac":"tagntrac.com","Xometry":"xometry.com",
};

const LOGO_DIR = "icons/logos";
const slug = n => n.toLowerCase().replace(/[^a-z0-9]+/g, "-").replace(/^-|-$/g, "");

// ---------- logo fetch (Clearbit -> Google favicon) ----------
function download(url, dest, redirects = 0) {
  return new Promise(resolve => {
    const req = https.get(url, { timeout: 9000, headers: { "User-Agent": "Mozilla/5.0" } }, res => {
      if ([301, 302, 303, 307, 308].includes(res.statusCode) && res.headers.location && redirects < 4) {
        res.resume();
        return resolve(download(res.headers.location, dest, redirects + 1));
      }
      if (res.statusCode !== 200) { res.resume(); return resolve(false); }
      const chunks = [];
      res.on("data", c => chunks.push(c));
      res.on("end", () => {
        const buf = Buffer.concat(chunks);
        if (buf.length < 400) return resolve(false); // junk / 1px placeholder
        fs.writeFileSync(dest, buf);
        resolve(true);
      });
    });
    req.on("error", () => resolve(false));
    req.on("timeout", () => { req.destroy(); resolve(false); });
  });
}

async function ensureLogos() {
  if (!fs.existsSync(LOGO_DIR)) fs.mkdirSync(LOGO_DIR, { recursive: true });
  let got = 0, miss = 0, skip = 0;
  for (const s of sectors) for (const co of s.cos) {
    const dest = path.join(LOGO_DIR, slug(co) + ".png");
    if (fs.existsSync(dest)) { skip++; continue; }
    const dom = DOMAINS[co];
    if (!dom) { miss++; continue; }
    let ok = await download(`https://logo.clearbit.com/${dom}?size=128&format=png`, dest);
    if (!ok) ok = await download(`https://www.google.com/s2/favicons?domain=${dom}&sz=128`, dest);
    if (ok) got++; else miss++;
    process.stdout.write(ok ? "." : "x");
  }
  console.log(`\nLogos: ${got} fetched, ${skip} cached, ${miss} fallback-to-monogram`);
}

function logoPath(co) {
  const f = path.join(LOGO_DIR, slug(co) + ".png");
  return fs.existsSync(f) ? f : null;
}

// ---------- layout ----------
const SLIDE_W = 13.333, SLIDE_H = 7.5, NAVY_W = 3.5;
const startX = 3.78, cardW = 2.96, gapH = 0.235;
const colX = [startX, startX + cardW + gapH, startX + 2 * (cardW + gapH)];
const topY = 0.56, gapV = 0.20;
const LINE = 0.165;
const FIRST = 0.62, BOTPAD = 0.12;
const CHIP = 0.13;             // logo / monogram diameter
const NSIZE = 8.5;            // name font size

function maxLen(arr){ return Math.max(...arr.map(s => s.length)); }
sectors.forEach(s => {
  s.twoCol = (s.cos.length >= 10 && maxLen(s.cos) <= 16);
  s.rows = s.twoCol ? Math.ceil(s.cos.length / 2) : s.cos.length;
  s.h = FIRST + s.rows * LINE + BOTPAD;
});

// bin-pack tallest-into-shortest across 3 columns
const colEnd = [topY, topY, topY];
const placed = [];
sectors.map((s,i)=>i).sort((a,b)=>sectors[b].h-sectors[a].h).forEach(i => {
  const c = colEnd.indexOf(Math.min(...colEnd));
  placed.push({ s: sectors[i], x: colX[c], y: colEnd[c] });
  colEnd[c] += sectors[i].h + gapV;
});

const TOTAL = sectors.reduce((n, s) => n + s.cos.length, 0);

// ---------- render ----------
function buildDeck() {
  const p = new pptxgen();
  p.defineLayout({ name: "W", width: SLIDE_W, height: SLIDE_H });
  p.layout = "W";
  const slide = p.addSlide();
  slide.background = { color: "FFFFFF" };

  // navy panel
  slide.addShape("rect", { x: 0, y: 0, w: NAVY_W, h: SLIDE_H, fill: { color: NAVY } });
  slide.addText("DELL TECHNOLOGIES CAPITAL", { x: 0.55, y: 0.62, w: 2.6, h: 0.5,
    fontFace: FONT, fontSize: 11, bold: true, color: SKY, charSpacing: 2 });
  slide.addText("Current\nPortfolio", { x: 0.5, y: 0.95, w: 3.0, h: 2.0,
    fontFace: FONT, fontSize: 42, bold: true, color: "FFFFFF", lineSpacingMultiple: 0.95 });
  slide.addText(String(TOTAL), { x: 0.5, y: 3.0, w: 3.0, h: 1.1,
    fontFace: FONT, fontSize: 76, bold: true, color: "FFFFFF" });
  slide.addText("PORTFOLIO COMPANIES", { x: 0.55, y: 4.28, w: 2.8, h: 0.4,
    fontFace: FONT, fontSize: 12, bold: true, color: SKY, charSpacing: 1 });
  slide.addText("7 sectors  \u00b7  FY2023 \u2013 FY2027", { x: 0.55, y: 4.68, w: 2.85, h: 0.4,
    fontFace: FONT, fontSize: 12, color: ICE });

  // one company row: chip (logo or monogram) + name
  function row(co, rx, ry, tw) {
    const lp = logoPath(co);
    if (lp) {
      // white rounded tile behind logo for consistent contrast
      slide.addShape("roundRect", { x: rx, y: ry, w: CHIP, h: CHIP, rectRadius: 0.02,
        fill: { color: "FFFFFF" }, line: { color: BORDER, width: 0.5 } });
      slide.addImage({ path: lp, x: rx + 0.008, y: ry + 0.008, w: CHIP - 0.016, h: CHIP - 0.016 });
    } else {
      slide.addShape("ellipse", { x: rx, y: ry, w: CHIP, h: CHIP, fill: { color: BLUE } });
      slide.addText(co.replace(/[^A-Za-z0-9]/g, "").charAt(0).toUpperCase(),
        { x: rx, y: ry - 0.012, w: CHIP, h: CHIP, fontFace: FONT, fontSize: 6.5, bold: true,
          color: "FFFFFF", align: "center", valign: "middle", margin: 0 });
    }
    slide.addText(co, { x: rx + CHIP + 0.05, y: ry - 0.035, w: tw, h: LINE,
      fontFace: FONT, fontSize: NSIZE, color: NAME, valign: "middle", margin: 0 });
  }

  placed.forEach(({ s, x, y }) => {
    slide.addShape("roundRect", { x, y, w: cardW, h: s.h, rectRadius: 0.07,
      fill: { color: CARD }, line: { color: BORDER, width: 1 } });
    // header: icon circle + glyph + title + count
    const cd = 0.30, cx = x + 0.16, cy = y + 0.15;
    slide.addShape("ellipse", { x: cx, y: cy, w: cd, h: cd, fill: { color: BLUE } });
    const id = 0.155;
    slide.addImage({ path: s.icon, x: cx + (cd - id) / 2, y: cy + (cd - id) / 2, w: id, h: id });
    slide.addText(s.title, { x: x + 0.55, y: y + 0.10, w: cardW - 0.55 - 0.42, h: 0.46,
      fontFace: FONT, fontSize: 10.5, bold: true, color: NAVY, valign: "middle", lineSpacingMultiple: 0.92 });
    slide.addText(String(s.cos.length), { x: x + cardW - 0.46, y: y + 0.14, w: 0.34, h: 0.32,
      fontFace: FONT, fontSize: 11, bold: true, color: BLUE, align: "right", valign: "middle" });

    // names
    const y0 = y + FIRST;
    if (s.twoCol) {
      const half = Math.ceil(s.cos.length / 2);
      const colW = (cardW - 0.16 - 0.12) / 2; // two inner columns
      const tw = colW - CHIP - 0.05 - 0.04;
      s.cos.slice(0, half).forEach((co, i) => row(co, x + 0.16, y0 + i * LINE, tw));
      s.cos.slice(half).forEach((co, i) => row(co, x + 0.16 + colW + 0.06, y0 + i * LINE, tw));
    } else {
      const tw = cardW - 0.16 - 0.12 - CHIP - 0.05;
      s.cos.forEach((co, i) => row(co, x + 0.16, y0 + i * LINE, tw));
    }
  });

  return p.writeFile({ fileName: "Current_Portfolio.pptx" });
}

(async () => {
  console.log(`Tallest column ends at ${Math.max(...colEnd.map(v=>v-gapV)).toFixed(2)}" (usable 7.36")  |  ${TOTAL} companies`);
  await ensureLogos();
  const f = await buildDeck();
  console.log("Wrote", f);
})();
